#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(int argc, string argv[])
{
    if (argc == 2)
    {
        printf("Hello, %sn", argv[1]);
    }
    else
    {
        printf("Hello, world\n");
    }
}